using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro; // ✅ เพิ่มเพื่อใช้แก้คำใน UI (ถ้าใช้ Text ธรรมดาให้เปลี่ยนเป็น using UnityEngine.UI;)

public class GameManager : MonoBehaviour
{
    public static bool isRestart = false;

    [Header("Game State")]
    public bool isGameActive = false;
    public bool isGameOver = false;

    [Header("Game Rules")]
    public int burntCount = 0;
    public int maxBurntAllowed = 5;
    public int cookedCount = 0;
    public int totalBeans = 0;

    [Header("UI References")]
    public GameObject gameOverPanel; // Panel หลัก
    public GameObject restartButton; // ปุ่มเริ่มใหม่
    public GameObject nextLevelButton; // ✅ ปุ่มไปด่านต่อไป (เพิ่มใหม่)
    public TMP_Text panelTitleText;  // ✅ ข้อความหัวข้อ (เช่น Game Over / You Win) - (ถ้าไม่มีให้ลบตัวแปรนี้ออก)

    [Header("Cooking Settings")]
    public float baseCookSpeed = 10f;
    public BeanSpawner beanSpawner;

    void Start()
    {
        // ซ่อนทุกอย่างตอนเริ่ม
        if (gameOverPanel != null) gameOverPanel.SetActive(false);
        if (restartButton != null) restartButton.SetActive(false);
        if (nextLevelButton != null) nextLevelButton.SetActive(false); // ซ่อนปุ่มใหม่ด้วย

        isGameActive = false;
        isGameOver = false;
        cookedCount = 0;
        burntCount = 0;
        Time.timeScale = 1;
    }

    public void StartGameplay()
    {
        isGameActive = true;
        if (beanSpawner != null) beanSpawner.SpawnBeans();

        BeanStatus[] allBeans = FindObjectsOfType<BeanStatus>();
        totalBeans = allBeans.Length;
    }

    void Update()
    {
        if (!isGameActive || isGameOver) return;

        float actualHeat = baseCookSpeed;
        if (HeatManager.Instance != null)
        {
            actualHeat = HeatManager.Instance.currentHeat * 0.05f;
        }

        BeanStatus[] allBeans = FindObjectsOfType<BeanStatus>();
        foreach (var bean in allBeans)
        {
            bean.AddHeat(actualHeat * Time.deltaTime);
        }
    }



    // ✅ ฟังก์ชันชนะเกม
    void WinGame()
    {
        isGameOver = true;
        Time.timeScale = 0;
        Debug.Log("🎉 YOU WIN!");

        ShowEndGamePanel(true); // เรียกฟังก์ชันโชว์ Panel แบบชนะ
    }

    // ✅ ฟังก์ชันแพ้เกม
    void GameOver()
    {
        if (isGameOver) return;
        isGameOver = true;
        Time.timeScale = 0;
        Debug.Log("❌ GAME OVER");

        ShowEndGamePanel(false); // เรียกฟังก์ชันโชว์ Panel แบบแพ้
    }

    // 🛠️ ฟังก์ชันจัดการ Panel (ใช้ร่วมกันทั้งแพ้และชนะ)
    void ShowEndGamePanel(bool isWin)
    {
        if (gameOverPanel != null) gameOverPanel.SetActive(true);

        if (isWin)
        {
            // ชนะ: ปิดปุ่มเริ่มใหม่ -> เปิดปุ่มไปต่อ
            if (restartButton != null) restartButton.SetActive(false);
            if (nextLevelButton != null) nextLevelButton.SetActive(true);

            // เปลี่ยนข้อความ (ถ้ามี)
            if (panelTitleText != null) panelTitleText.text = "ภารกิจสำเร็จ ! คุณคั่วถั่วได้สีสวยน่าทานมากค่ะ";
        }
        else
        {
            // แพ้: เปิดปุ่มเริ่มใหม่ -> ปิดปุ่มไปต่อ
            if (restartButton != null) restartButton.SetActive(true);
            if (nextLevelButton != null) nextLevelButton.SetActive(false);

            // เปลี่ยนข้อความ (ถ้ามี)
            if (panelTitleText != null) panelTitleText.text = "คุณคั่วถั่วไหม้ สีเข้มเกินไปเยอะเกินไปแล้ว กดปุ่มเพื่อเริ่มใหม่";
        }
    }

    public void RetryGame()
    {
        isRestart = true;
        Time.timeScale = 1;
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    // ✅ ฟังก์ชันสำหรับปุ่ม Next Level
    public void GoToNextLevel()
    {
        Time.timeScale = 1; // คืนค่าเวลา
                            // ใส่ชื่อ Scene ถัดไปตรงนี้ หรือใช้ index + 1
                            //SceneManager.LoadScene("Level2"); 

        // หรือโหลดฉากถัดไปตามลำดับใน Build Settings
        int nextSceneIndex = SceneManager.GetActiveScene().buildIndex + 1;
        SceneManager.LoadScene(nextSceneIndex);
    }

    void CheckWinCondition()
    {
        // ถ้าเกมจบไปแล้ว ไม่ต้องเช็ค
        if (isGameOver) return;

        // สูตรใหม่: (สุก + ไหม้) ต้องเท่ากับจำนวนถั่วทั้งหมด
        int finishedBeans = cookedCount + burntCount;

        Debug.Log($"สถานะตอนนี้: สุก {cookedCount} + ไหม้ {burntCount} = {finishedBeans}/{totalBeans}");

        if (finishedBeans >= totalBeans)
        {
            // เช็คอีกทีว่ายอดไหม้เกินไหม? (กันพลาด)
            if (burntCount < maxBurntAllowed)
            {
                WinGame();
            }
            else
            {
                // ถ้าครบจำนวนแต่ไหม้เกิน ก็คือ Game Over (ซึ่งปกติจะดักไว้ก่อนแล้ว)
                GameOver();
            }
        }
    }

    public void ReportCookedBean(bool increment)
    {
        if (isGameOver) return;

        if (increment) cookedCount++;
        else cookedCount--;

        // เช็คชนะทุกครั้งที่มีการเปลี่ยนแปลง
        CheckWinCondition();
    }

    public void ReportBurntBean()
    {
        if (isGameOver || !isGameActive) return;

        burntCount++;

        // เช็คแพ้ก่อน
        if (burntCount >= maxBurntAllowed)
        {
            GameOver();
        }
        else
        {
            // ถ้ายังไม่แพ้ ให้เช็คว่า "อาจจะชนะแล้วหรือเปล่า?"
            // (เช่น เหลือเม็ดสุดท้าย แล้วมันไหม้พอดี ทำให้ครบจำนวน)
            CheckWinCondition();
        }
    }
}